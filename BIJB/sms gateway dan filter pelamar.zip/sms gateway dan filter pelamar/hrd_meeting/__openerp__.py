{
    "name":"Calendar Events",
    "version":"0.1",
    "author":"vitraining.com",
    "website":"http://vitraining.com",
    "category":"Custom Modules/Human Resources",
    "description": """
        one2many pelamar yang akan di interview di calendar event.
    """,
    "depends":["calendar","hrd_recruitment"],
    "init_xml":[],
    "demo_xml":[],
    "update_xml":[
                  "interview_view.xml",
                  ],
    "active":False,
    "installable":True
}
